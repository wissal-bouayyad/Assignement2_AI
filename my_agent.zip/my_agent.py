from oxono import State, Game
from agent_helper_move_ordering import Iterative_deepening_alpha_beta_search
from agent import Agent

class MyAgent(Agent):
    def act(self, state, remaining_time):

        try: 
            return Iterative_deepening_alpha_beta_search(Game, state,remaining_time)    
        except TimeoutError:
            print("timeout")
            return None
            